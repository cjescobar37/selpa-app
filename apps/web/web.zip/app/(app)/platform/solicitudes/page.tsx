'use client'

import { useEffect, useMemo, useState } from 'react'
import { supabase } from '@/lib/supabaseClient'

type ClubRequest = {
  id: string
  created_at?: string
  club_name: string
  brand_name?: string | null
  city?: string | null
  province?: string | null
  contact_email?: string | null
  phone?: string | null
  website?: string | null
  instagram?: string | null
  courts_count?: number | null
  courts_surface?: string | null
  notes?: string | null
  owner_name?: string | null
  owner_email?: string | null
  owner_phone?: string | null
}

export default function PlatformSolicitudesPage() {
  const [loading, setLoading] = useState(true)
  const [busyId, setBusyId] = useState<string | null>(null)
  const [rows, setRows] = useState<ClubRequest[]>([])
  const [msg, setMsg] = useState('')
  const [rejectingId, setRejectingId] = useState<string | null>(null)
  const [reasons, setReasons] = useState<Record<string, string>>({})

  async function load() {
    setLoading(true)
    setMsg('')
    const { data: sess } = await supabase.auth.getSession()
    const token = sess?.session?.access_token

    if (!token) {
      setMsg('Tenés que iniciar sesión como superadmin.')
      setLoading(false)
      return
    }

    const res = await fetch('/api/club-requests', {
      headers: { Authorization: `Bearer ${token}` },
      cache: 'no-store',
    })
    const json = await res.json().catch(() => ({}))

    if (!res.ok) {
      setMsg(json?.error ?? 'No pude cargar las solicitudes.')
      setLoading(false)
      return
    }

    setRows(json?.requests ?? [])
    setLoading(false)
  }

  useEffect(() => {
    load()
  }, [])

  const ordered = useMemo(() => rows, [rows])

  async function applyAction(id: string, action: 'approve' | 'reject') {
    setBusyId(id)
    setMsg('')
    const { data: sess } = await supabase.auth.getSession()
    const token = sess?.session?.access_token
    if (!token) {
      setMsg('Sesión expirada.')
      setBusyId(null)
      return
    }

    const rejectionReason = (reasons[id] ?? '').trim()
    const res = await fetch(`/api/club-requests/${id}`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ action, rejectionReason }),
    })
    const json = await res.json().catch(() => ({}))
    setBusyId(null)

    if (!res.ok) {
      setMsg(json?.error ?? 'No pude procesar la solicitud.')
      return
    }

    setRejectingId(null)
    setReasons((prev) => ({ ...prev, [id]: '' }))
    setRows((prev) => prev.filter((row) => row.id !== id))
    setMsg(action === 'approve' ? 'Solicitud aprobada y club dado de alta.' : 'Solicitud rechazada.')
  }

  return (
    <div className="px-wrap">
      <div className="px-pageHead" style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
        <div>
          <h1 className="px-pageTitle">Solicitudes de alta de club</h1>
          <p className="px-pageSub">Aprobá o denegá pedidos de clubes sin tocar el resto del sistema.</p>
        </div>
        <button type="button" onClick={load} className="px-btn px-btn--ghost" disabled={loading}>
          {loading ? 'Actualizando…' : 'Actualizar'}
        </button>
      </div>

      {msg ? <div className="px-help" style={{ marginBottom: 14 }}>{msg}</div> : null}

      {loading ? (
        <div className="px-help">Cargando solicitudes…</div>
      ) : ordered.length === 0 ? (
        <div className="px-help">No hay solicitudes pendientes.</div>
      ) : (
        <div style={{ display: 'grid', gap: 14 }}>
          {ordered.map((row) => {
            const isBusy = busyId === row.id
            const isRejecting = rejectingId === row.id
            return (
              <div key={row.id} className="px-card px-card--flat" style={{ display: 'grid', gap: 14 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap' }}>
                  <div style={{ display: 'grid', gap: 4 }}>
                    <div style={{ fontSize: 20, fontWeight: 900, color: '#17253f' }}>{row.club_name}</div>
                    <div className="px-muted">
                      {[row.city, row.province].filter(Boolean).join(', ') || 'Sin ubicación'}
                      {row.created_at ? ` · ${new Date(row.created_at).toLocaleString('es-AR')}` : ''}
                    </div>
                  </div>

                  <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                    <button type="button" className="px-btn" onClick={() => applyAction(row.id, 'approve')} disabled={isBusy}>
                      {isBusy ? 'Procesando…' : 'Aprobar'}
                    </button>
                    <button
                      type="button"
                      className="px-btn px-btn--ghost"
                      onClick={() => setRejectingId(isRejecting ? null : row.id)}
                      disabled={isBusy}
                    >
                      Rechazar
                    </button>
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 12 }}>
                  <Info label="Responsable" value={row.owner_name || '—'} />
                  <Info label="Email admin" value={row.owner_email || '—'} />
                  <Info label="Teléfono admin" value={row.owner_phone || '—'} />
                  <Info label="Email contacto" value={row.contact_email || '—'} />
                  <Info label="Teléfono club" value={row.phone || '—'} />
                  <Info label="Branding" value={row.brand_name || '—'} />
                  <Info label="Website" value={row.website || '—'} />
                  <Info label="Instagram" value={row.instagram || '—'} />
                  <Info label="Canchas" value={row.courts_count ? String(row.courts_count) : '—'} />
                  <Info label="Superficie" value={row.courts_surface || '—'} />
                </div>

                {row.notes ? (
                  <div style={{ padding: 12, borderRadius: 14, background: 'rgba(82,196,217,0.08)', color: '#17253f' }}>
                    <b>Notas:</b> {row.notes}
                  </div>
                ) : null}

                {isRejecting ? (
                  <div style={{ display: 'grid', gap: 10 }}>
                    <textarea
                      className="px-input"
                      rows={3}
                      placeholder="Motivo del rechazo"
                      value={reasons[row.id] ?? ''}
                      onChange={(e) => setReasons((prev) => ({ ...prev, [row.id]: e.target.value }))}
                    />
                    <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                      <button
                        type="button"
                        className="px-btn"
                        onClick={() => applyAction(row.id, 'reject')}
                        disabled={isBusy}
                      >
                        Confirmar rechazo
                      </button>
                      <button type="button" className="px-btn px-btn--ghost" onClick={() => setRejectingId(null)}>
                        Cancelar
                      </button>
                    </div>
                  </div>
                ) : null}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div style={{ padding: 12, borderRadius: 14, background: 'rgba(245,247,251,0.95)', border: '1px solid rgba(20,33,61,0.08)' }}>
      <div style={{ fontSize: 12, fontWeight: 800, color: 'rgba(23,37,63,.58)', textTransform: 'uppercase', letterSpacing: '.04em' }}>{label}</div>
      <div style={{ marginTop: 4, color: '#17253f', fontWeight: 700, wordBreak: 'break-word' }}>{value}</div>
    </div>
  )
}
