'use client'

import { useEffect, useMemo, useState } from 'react'
import Link from 'next/link'
import { useRouter, useSearchParams } from 'next/navigation'
import { supabase } from '@/lib/supabaseClient'
import AuthAlert from '@/components/AuthAlert'

type AlertState = { variant: 'success' | 'warning' | 'error' | 'info'; title: string; message?: string } | null

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true">
      <path fill="#EA4335" d="M12 10.2v3.9h5.5c-.2 1.2-.9 2.3-1.9 3l3 2.3c1.8-1.6 2.9-4 2.9-6.8 0-.7-.1-1.3-.2-1.9z" />
      <path fill="#34A853" d="M12 21c2.7 0 4.9-.9 6.5-2.5l-3-2.3c-.8.6-1.9 1-3.5 1-2.6 0-4.8-1.8-5.6-4.1l-3.1 2.4C5 18.8 8.2 21 12 21z" />
      <path fill="#4A90E2" d="M6.4 13.1c-.2-.6-.3-1.2-.3-1.9s.1-1.3.3-1.9L3.3 6.9C2.5 8.4 2 10.1 2 12s.5 3.6 1.3 5.1z" />
      <path fill="#FBBC05" d="M12 6.8c1.5 0 2.8.5 3.8 1.5l2.8-2.8C16.9 3.9 14.7 3 12 3 8.2 3 5 5.2 3.3 8.5l3.1 2.4C7.2 8.6 9.4 6.8 12 6.8z" />
    </svg>
  )
}

function isEmailNotConfirmed(message?: string) {
  const lower = (message || '').toLowerCase()
  return lower.includes('email not confirmed') || lower.includes('confirm your email')
}

export default function LoginPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [identifier, setIdentifier] = useState('')
  const [password, setPassword] = useState('')
  const [alert, setAlert] = useState<AlertState>(null)
  const [loading, setLoading] = useState(false)
  const [resending, setResending] = useState(false)
  const [showResendConfirmation, setShowResendConfirmation] = useState(false)

  const callbackUrl = useMemo(() => {
    if (typeof window === 'undefined') return ''
    return `${window.location.origin}/auth/callback?next=/auth/post-login`
  }, [])

  useEffect(() => {
    const confirmed = searchParams.get('confirmed')
    const error = searchParams.get('error')
    const recovered = searchParams.get('recovered')

    if (confirmed === '1') {
      setAlert({
        variant: 'success',
        title: 'Email confirmado',
        message: 'Tu cuenta quedó validada. Ahora podés ingresar.',
      })
      setShowResendConfirmation(false)
      return
    }

    if (recovered === '1') {
      setAlert({
        variant: 'success',
        title: 'Recuperación validada',
        message: 'Ahora definí tu nueva contraseña.',
      })
      setShowResendConfirmation(false)
      return
    }

    if (error) {
      setAlert({
        variant: 'error',
        title: 'No se pudo completar la validación',
        message: decodeURIComponent(error),
      })
      setShowResendConfirmation(false)
    }
  }, [searchParams])

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data?.session?.user) router.replace('/auth/post-login')
    })
  }, [router])

  async function signInWithGoogle() {
    setAlert({ variant: 'info', title: 'Redirigiendo a Google…' })
    setLoading(true)
    setShowResendConfirmation(false)

    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: callbackUrl,
        queryParams: {
          access_type: 'offline',
          prompt: 'select_account',
        },
      },
    })

    if (error) {
      setAlert({ variant: 'error', title: 'No se pudo iniciar sesión con Google', message: error.message })
      setLoading(false)
    }
  }

  async function signInWithEmail() {
    if (!identifier || !password) {
      setAlert({ variant: 'warning', title: 'Faltan datos', message: 'Completá email / CUIT / slug y contraseña.' })
      setShowResendConfirmation(false)
      return
    }

    setLoading(true)
    setAlert({ variant: 'info', title: 'Ingresando…' })
    setShowResendConfirmation(false)

    let resolvedEmail = identifier.trim().toLowerCase()
    if (!resolvedEmail.includes('@')) {
      const res = await fetch('/api/auth/resolve-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier: resolvedEmail }),
      })
      const json = await res.json().catch(() => ({}))
      if (!res.ok) {
        setAlert({ variant: 'error', title: 'No encontramos ese acceso', message: json?.error ?? 'Revisá el CUIT, slug o email.' })
        setLoading(false)
        return
      }
      resolvedEmail = String(json.email || '').toLowerCase()
    }

    const { error } = await supabase.auth.signInWithPassword({ email: resolvedEmail, password })

    if (error) {
      if (isEmailNotConfirmed(error.message)) {
        setAlert({
          variant: 'warning',
          title: 'Tenés que confirmar tu email',
          message: 'Abrí el link que te enviamos por correo. Si no lo encontrás, reenviá la confirmación.',
        })
        setShowResendConfirmation(true)
      } else {
        setAlert({ variant: 'error', title: 'Credenciales inválidas', message: error.message })
        setShowResendConfirmation(false)
      }
      setLoading(false)
      return
    }

    setAlert({ variant: 'success', title: '¡Listo! Entraste correctamente.' })
    setShowResendConfirmation(false)
    router.replace('/auth/post-login')
  }

  async function resendConfirmation() {
    const email = identifier.trim().toLowerCase()
    if (!email || !email.includes('@')) {
      setAlert({
        variant: 'warning',
        title: 'Indicá tu email',
        message: 'Para reenviar la confirmación necesitás escribir tu email exacto.',
      })
      return
    }

    setResending(true)
    const { error } = await supabase.auth.resend({
      type: 'signup',
      email,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/confirm?next=${encodeURIComponent('/login?confirmed=1')}`,
      },
    })

    if (error) {
      setAlert({ variant: 'error', title: 'No se pudo reenviar', message: error.message })
      setResending(false)
      return
    }

    setAlert({
      variant: 'success',
      title: 'Email reenviado',
      message: 'Revisá tu bandeja y también spam o promociones.',
    })
    setResending(false)
  }

  return (
    <div className="px-auth">
      <div className="px-authCard">
        <div className="px-authTop">
          <div className="px-authBrand">
            <div className="px-authLogo">PX</div>
            <div className="px-authBrandText">
              <h1 className="px-authTitle">Ingresar</h1>
              <p className="px-authSub">Ranking • Torneos • Clubes</p>
            </div>
          </div>
        </div>

        <div className="px-authBody">
          <button className="px-btn px-btn--ghost" onClick={signInWithGoogle} disabled={loading}>
            {loading ? (
              <>
                <span className="px-spinner" />&nbsp;Conectando...
              </>
            ) : (
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10, justifyContent: 'center', width: '100%' }}>
                <GoogleIcon />
                <span>Continuar con Google</span>
              </span>
            )}
          </button>

          <div className="px-sepRow">o</div>

          <div className="px-field">
            <label className="px-label">Email / CUIT / slug del club</label>
            <input
              className="px-input"
              value={identifier}
              onChange={e => setIdentifier(e.target.value)}
              placeholder="tu@email.com · 30712345678 · la33-santarosa"
              autoComplete="username"
            />
          </div>

          <div className="px-field">
            <label className="px-label">Contraseña</label>
            <input
              className="px-input"
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="••••••••"
              autoComplete="current-password"
            />
          </div>

          <button className="px-btn" onClick={signInWithEmail} disabled={loading}>
            {loading ? (
              <>
                <span className="px-spinner" />&nbsp;Entrando...
              </>
            ) : (
              'Entrar'
            )}
          </button>

          {showResendConfirmation ? (
            <button className="px-btn px-btn--ghost" onClick={resendConfirmation} disabled={resending || loading}>
              {resending ? 'Reenviando confirmación…' : 'Reenviar confirmación de email'}
            </button>
          ) : null}

          {alert ? <AuthAlert variant={alert.variant} title={alert.title} message={alert.message} /> : null}

          <div className="px-authRow">
            <Link className="px-link" href="/register">Crear cuenta</Link>
            <Link className="px-link" href="/reset-password">Olvidé mi contraseña</Link>
          </div>
        </div>
      </div>
    </div>
  )
}