'use client'

import { useEffect, useMemo, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabaseClient'
import AuthAlert from '@/components/AuthAlert'

type AlertState = { variant: 'success' | 'warning' | 'error' | 'info'; title: string; message?: string } | null

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true">
      <path fill="#EA4335" d="M12 10.2v3.9h5.5c-.2 1.2-.9 2.3-1.9 3l3 2.3c1.8-1.6 2.9-4 2.9-6.8 0-.7-.1-1.3-.2-1.9z" />
      <path fill="#34A853" d="M12 21c2.7 0 4.9-.9 6.5-2.5l-3-2.3c-.8.6-1.9 1-3.5 1-2.6 0-4.8-1.8-5.6-4.1l-3.1 2.4C5 18.8 8.2 21 12 21z" />
      <path fill="#4A90E2" d="M6.4 13.1c-.2-.6-.3-1.2-.3-1.9s.1-1.3.3-1.9L3.3 6.9C2.5 8.4 2 10.1 2 12s.5 3.6 1.3 5.1z" />
      <path fill="#FBBC05" d="M12 6.8c1.5 0 2.8.5 3.8 1.5l2.8-2.8C16.9 3.9 14.7 3 12 3 8.2 3 5 5.2 3.3 8.5l3.1 2.4C7.2 8.6 9.4 6.8 12 6.8z" />
    </svg>
  )
}

export default function RegisterPage() {
  const router = useRouter()

  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [displayName, setDisplayName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [password2, setPassword2] = useState('')
  const [alert, setAlert] = useState<AlertState>(null)
  const [loading, setLoading] = useState(false)

  const callbackUrl = useMemo(() => {
    if (typeof window === 'undefined') return ''
    return `${window.location.origin}/auth/callback?next=/auth/post-login`
  }, [])

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data?.user) router.replace('/')
    })
  }, [router])

  async function signUpWithGoogle() {
    setAlert({ variant: 'info', title: 'Redirigiendo a Google…' })
    setLoading(true)

    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: callbackUrl,
        queryParams: {
          access_type: 'offline',
          prompt: 'select_account',
        },
      },
    })

    if (error) {
      setAlert({ variant: 'error', title: 'No se pudo continuar con Google', message: error.message })
      setLoading(false)
    }
  }

  async function signUp() {
    const cleanEmail = email.trim().toLowerCase()

    if (!cleanEmail || !password) {
      setAlert({ variant: 'warning', title: 'Faltan datos', message: 'Completá email y contraseña.' })
      return
    }
    if (password !== password2) {
      setAlert({ variant: 'warning', title: 'Revisá las contraseñas', message: 'No coinciden.' })
      return
    }
    if (password.length < 6) {
      setAlert({ variant: 'warning', title: 'Contraseña débil', message: 'Debe tener al menos 6 caracteres.' })
      return
    }

    setLoading(true)
    setAlert({ variant: 'info', title: 'Creando cuenta…' })

    const { data, error } = await supabase.auth.signUp({
      email: cleanEmail,
      password,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/confirm?next=${encodeURIComponent('/login?confirmed=1')}`,
        data: {
          first_name: firstName || null,
          last_name: lastName || null,
          display_name: displayName || null,
        },
      },
    })

    if (error) {
      setAlert({ variant: 'error', title: 'No se pudo crear la cuenta', message: error.message })
      setLoading(false)
      return
    }

    const userId = data.user?.id
    if (userId) {
      await supabase
        .from('profiles')
        .update({
          first_name: firstName || null,
          last_name: lastName || null,
          display_name: displayName || null,
          email: cleanEmail || null,
        })
        .eq('user_id', userId)
    }

    setAlert({
      variant: 'success',
      title: 'Cuenta creada',
      message: 'Te enviamos un email para confirmar la cuenta. Confirmalo antes de ingresar.',
    })
    setLoading(false)
    setTimeout(() => router.replace('/login'), 1200)
  }

  return (
    <div className="px-auth">
      <div className="px-authCard">
        <div className="px-authTop">
          <div className="px-authBrand">
            <div className="px-authLogo">PX</div>
            <div className="px-authBrandText">
              <h1 className="px-authTitle">Crear cuenta</h1>
              <p className="px-authSub">Registrate con tus datos y empezá a jugar.</p>
            </div>
          </div>
        </div>

        <div className="px-authBody">
          <button className="px-btn px-btn--ghost" onClick={signUpWithGoogle} disabled={loading}>
            {loading ? (
              <>
                <span className="px-spinner" />&nbsp;Conectando...
              </>
            ) : (
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10, justifyContent: 'center', width: '100%' }}>
                <GoogleIcon />
                <span>Registrarme con Google</span>
              </span>
            )}
          </button>

          <div className="px-sepRow">o</div>

          <div className="px-field">
            <label className="px-label">Nombre</label>
            <input className="px-input" value={firstName} onChange={e => setFirstName(e.target.value)} />
          </div>

          <div className="px-field">
            <label className="px-label">Apellido</label>
            <input className="px-input" value={lastName} onChange={e => setLastName(e.target.value)} />
          </div>

          <div className="px-field">
            <label className="px-label">Nombre visible</label>
            <input
              className="px-input"
              value={displayName}
              onChange={e => setDisplayName(e.target.value)}
              placeholder="Ej: Cristian Escobar"
            />
          </div>

          <div className="px-field">
            <label className="px-label">Email</label>
            <input
              className="px-input"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="tu@email.com"
              autoComplete="email"
            />
          </div>

          <div className="px-field">
            <label className="px-label">Contraseña</label>
            <input
              className="px-input"
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="••••••••"
              autoComplete="new-password"
            />
          </div>

          <div className="px-field">
            <label className="px-label">Repetir contraseña</label>
            <input
              className="px-input"
              type="password"
              value={password2}
              onChange={e => setPassword2(e.target.value)}
              placeholder="••••••••"
              autoComplete="new-password"
            />
          </div>

          <button className="px-btn" onClick={signUp} disabled={loading}>
            {loading ? (
              <>
                <span className="px-spinner" />&nbsp;Creando...
              </>
            ) : (
              'Crear cuenta'
            )}
          </button>

          {alert ? <AuthAlert variant={alert.variant} title={alert.title} message={alert.message} /> : null}

          <div className="px-authRow">
            <span className="px-muted">¿Ya tenés cuenta?</span>
            <Link className="px-link" href="/login">Ingresar</Link>
          </div>
        </div>
      </div>
    </div>
  )
}