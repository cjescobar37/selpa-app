import { NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabaseAdmin'

type RequestPayload = {
  club_name?: string
  brand_name?: string
  legal_name?: string
  cuit?: string
  email?: string
  phone?: string
  website?: string
  instagram?: string
  address?: string
  city?: string
  province?: string
  country?: string
  opening_hours?: string
  courts_count?: string | number
  courts_surface?: string
  logo_url?: string
  rules_pdf_url?: string
  notes?: string
  admin_name?: string
  admin_email?: string
  admin_phone?: string
}

async function getTokenUser(req: Request) {
  const auth = req.headers.get('authorization') || ''
  const bodyToken = req.headers.get('x-access-token') || ''
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : bodyToken
  if (!token) return null

  const { data, error } = await supabaseAdmin.auth.getUser(token)
  if (error || !data?.user) return null
  return data.user
}

export async function GET(req: Request) {
  try {
    const user = await getTokenUser(req)
    if (!user) {
      return NextResponse.json({ error: 'Sesión inválida.' }, { status: 401 })
    }

    const { data: pa, error: paErr } = await supabaseAdmin
      .from('platform_admins')
      .select('user_id')
      .eq('user_id', user.id)
      .maybeSingle()

    if (paErr) return NextResponse.json({ error: paErr.message }, { status: 500 })
    if (!pa?.user_id) return NextResponse.json({ error: 'No autorizado.' }, { status: 403 })

    const { data, error } = await supabaseAdmin
      .from('club_requests')
      .select('*')
      .order('created_at', { ascending: false })

    if (error) return NextResponse.json({ error: error.message }, { status: 500 })
    return NextResponse.json({ requests: data ?? [] })
  } catch (e: any) {
    return NextResponse.json({ error: e?.message ?? 'Error cargando solicitudes.' }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const user = await getTokenUser(req)
    if (!user) {
      return NextResponse.json({ error: 'Tenés que iniciar sesión para solicitar el alta de un club.' }, { status: 401 })
    }

    const body = (await req.json()) as RequestPayload
    const payload = {
      club_name: (body.club_name ?? '').trim(),
      brand_name: (body.brand_name ?? '').trim() || null,
      legal_name: (body.legal_name ?? '').trim() || null,
      cuit: String(body.cuit ?? '').replace(/\D/g, '') || null,
      contact_email: (body.email ?? '').trim().toLowerCase(),
      phone: (body.phone ?? '').trim() || null,
      website: (body.website ?? '').trim() || null,
      instagram: (body.instagram ?? '').trim() || null,
      address: (body.address ?? '').trim() || null,
      city: (body.city ?? '').trim() || null,
      province: (body.province ?? '').trim() || null,
      country: (body.country ?? '').trim() || 'Argentina',
      opening_hours: (body.opening_hours ?? '').trim() || null,
      courts_count: body.courts_count ? Number(body.courts_count) : null,
      courts_surface: (body.courts_surface ?? '').trim() || null,
      logo_url: (body.logo_url ?? '').trim() || null,
      rules_pdf_url: (body.rules_pdf_url ?? '').trim() || null,
      notes: (body.notes ?? '').trim() || null,
      owner_name: (body.admin_name ?? '').trim(),
      owner_email: (body.admin_email ?? '').trim().toLowerCase(),
      owner_phone: (body.admin_phone ?? '').trim() || null,
    }

    if (!payload.club_name || !payload.contact_email || !payload.owner_name || !payload.owner_email) {
      return NextResponse.json({ error: 'Faltan campos obligatorios.' }, { status: 400 })
    }

    const duplicate = await supabaseAdmin
      .from('club_requests')
      .select('id')
      .eq('club_name', payload.club_name)
      .eq('owner_email', payload.owner_email)
      .limit(1)
      .maybeSingle()

    if (duplicate.data?.id) {
      return NextResponse.json({ error: 'Ya existe una solicitud pendiente para este club con ese email.' }, { status: 409 })
    }

    const { data: inserted, error } = await supabaseAdmin
      .from('club_requests')
      .insert(payload)
      .select('*')
      .single()

    if (error) return NextResponse.json({ error: error.message }, { status: 500 })

    const { data: admins } = await supabaseAdmin.from('platform_admins').select('user_id')
    if (admins?.length) {
      await supabaseAdmin.from('notifications').insert(
        admins.map((row) => ({
          user_id: row.user_id,
          type: 'club_request_created',
          title: 'Nueva solicitud de club',
          message: `${payload.club_name} pidió alta de club y está pendiente de revisión.`,
          link: '/platform/solicitudes',
          metadata: {
            request_id: inserted?.id ?? null,
            club_name: payload.club_name,
            owner_email: payload.owner_email,
            requester_user_id: user.id,
          },
        }))
      )
    }

    return NextResponse.json({ ok: true, request: inserted })
  } catch (e: any) {
    return NextResponse.json({ error: e?.message ?? 'Error' }, { status: 500 })
  }
}
