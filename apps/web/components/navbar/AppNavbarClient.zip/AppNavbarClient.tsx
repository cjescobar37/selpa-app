'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import React, { useEffect, useMemo, useRef, useState } from 'react'
import {
  Bell,
  Mail,
  Search,
  ChevronDown,
  User,
  Activity,
  Settings,
  LogOut,
  Shield,
  Menu,
  X,
} from 'lucide-react'

import { NAV_CONFIG, type NavItem } from '@/lib/navConfig'
import { useSession } from '@/components/session/SessionProvider'

function initials(text?: string) {
  if (!text) return 'PX'
  const parts = text.trim().split(/\s+/).slice(0, 2)
  return parts.map(p => p[0]?.toUpperCase()).join('') || 'PX'
}

function shortName(name?: string, max = 14) {
  const n = (name ?? '').trim()
  if (!n) return ''
  if (n.length <= max) return n
  return n.slice(0, max - 1) + '…'
}

export default function AppNavbarClient() {
  const pathname = usePathname()
  const router = useRouter()
  const rootRef = useRef<HTMLDivElement | null>(null)

  const { status, role, user, clubs, activeClub, setActiveClub, signOut } = useSession()
  const cfg = NAV_CONFIG[role]

  const notifCount = 1
  const mailCount = 3
  const liveDot = true

  const [clubOpen, setClubOpen] = useState(false)
  const [userOpen, setUserOpen] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [navOpen, setNavOpen] = useState<string | null>(null)

  // ✅ navbar transparente al scrollear
  const [scrolled, setScrolled] = useState(false)
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 6)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  // anti-flicker hover close
  const closeTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const clearCloseTimer = () => {
    if (closeTimer.current) {
      clearTimeout(closeTimer.current)
      closeTimer.current = null
    }
  }
  const scheduleClose = (href: string) => {
    clearCloseTimer()
    closeTimer.current = setTimeout(() => {
      setNavOpen(v => (v === href ? null : v))
    }, 120)
  }

  useEffect(() => {
    const onDown = (e: MouseEvent) => {
      const target = e.target as Node
      if (!rootRef.current) return
      if (!rootRef.current.contains(target)) {
        setClubOpen(false)
        setUserOpen(false)
        setNavOpen(null)
        clearCloseTimer()
      }
    }
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setClubOpen(false)
        setUserOpen(false)
        setMobileOpen(false)
        setNavOpen(null)
        clearCloseTimer()
      }
    }
    document.addEventListener('mousedown', onDown)
    window.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('mousedown', onDown)
      window.removeEventListener('keydown', onKey)
    }
  }, [])

  useEffect(() => {
    setMobileOpen(false)
    setClubOpen(false)
    setUserOpen(false)
    setNavOpen(null)
    clearCloseTimer()
  }, [pathname])

  const mainNav: NavItem[] = useMemo(() => {
    return cfg.main.map(i => (i.label.toLowerCase().includes('en vivo') ? { ...i, dot: liveDot } : i))
  }, [cfg.main])

  const normalizePath = (p?: string | null) => {
    const s = (p ?? '/')
    return s.length > 1 ? s.replace(/\/+$/g, '') : s
  }

  const isActiveHref = (href: string, exact?: boolean) => {
    const p = normalizePath(pathname)
    const h = normalizePath(href)
    if (exact) return p === h
    return p === h || p.startsWith(h + '/')
  }

  const isActiveItem = (item: NavItem) => {
    if (isActiveHref(item.href, item.exact)) return true
    if (item.children?.length) return item.children.some(ch => isActiveHref(ch.href))
    return false
  }

  const onLogin = () => router.push('/login')

  const onLogout = async () => {
    await signOut()
    router.replace('/login')
    router.refresh()
  }

  const leftBrand = (
    <Link href="/" className="px-brand" aria-label="PAMPRAX">
      <span className="px-clubLogo">
        <span>P X</span>
      </span>
      <span className="px-clubText">
        <span className="px-clubName">PAMPRAX</span>
      </span>
    </Link>
  )

  const leftClub = (
    <div className="px-dd">
      <button
        className="px-clubBtn"
        type="button"
        onClick={() => {
          setClubOpen(v => !v)
          setUserOpen(false)
          setNavOpen(null)
          clearCloseTimer()
        }}
        aria-expanded={clubOpen}
        aria-haspopup="menu"
        disabled={status === 'loading'}
      >
        <span className="px-clubLogo">
          {activeClub?.logoUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={activeClub.logoUrl} alt="" />
          ) : (
            <span>{initials(activeClub?.name ?? 'Mi club')}</span>
          )}
        </span>

        <span className="px-clubText">
          <span className="px-clubName">{shortName(activeClub?.name ?? 'MI CLUB', 16)}</span>
        </span>

        <ChevronDown size={16} className={clubOpen ? 'px-rot' : ''} />
      </button>

      {clubOpen ? (
        <div className="px-menu" role="menu">
          <button className="px-menuItem" role="menuitem" type="button" onClick={() => { setClubOpen(false); router.push('/club') }}>
            <Shield size={16} />
            Ver club
          </button>

          <div className="px-menuSep" />

          <div className="px-menuGroupTitle">Cambiar club</div>
          {clubs.length ? (
            clubs.map(c => (
              <button
                key={c.id}
                className={['px-menuItem', c.id === activeClub?.id ? 'px-menuItem--active' : ''].join(' ')}
                role="menuitem"
                type="button"
                onClick={async () => {
                  await setActiveClub(c.id)
                  setClubOpen(false)
                }}
              >
                {c.name}
                {c.id === activeClub?.id ? <span className="px-pill">Activo</span> : null}
              </button>
            ))
          ) : (
            <div className="px-menuItem" style={{ opacity: 0.75 }}>
              No tenés clubes aprobados.
            </div>
          )}

          <div className="px-menuSep" />

          <button className="px-menuItem" role="menuitem" type="button" onClick={() => { setClubOpen(false); router.push('/club/configuracion') }}>
            <Settings size={16} />
            Info del club
          </button>
        </div>
      ) : null}
    </div>
  )

  return (
    <header className={['px-navbar', scrolled ? 'px-navbar--scrolled' : ''].join(' ')} ref={rootRef}>
      <div className="px-navbar-inner px-navgrid">
        {/* LEFT */}
        <div className="px-left">
          <button className="px-burgerBtn px-mobileOnly" type="button" aria-label="Abrir menú" onClick={() => setMobileOpen(true)}>
            <Menu size={18} />
          </button>
          {cfg.leftMode === 'club' ? leftClub : leftBrand}
        </div>

        {/* CENTER desktop */}
        <nav className="px-navlinks px-desktopOnly" aria-label="Primary">
          {mainNav.map(item => {
            const active = isActiveItem(item)
            const hasChildren = !!item.children?.length

            if (!hasChildren) {
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={['px-navlink', active ? 'px-navlink--active' : ''].join(' ')}
                >
                  {item.label}
                  {item.dot ? <span className="px-dot" aria-hidden="true" /> : null}
                </Link>
              )
            }

            const open = navOpen === item.href

            return (
              <div
                key={item.href}
                className="px-dd px-navDropWrap"
                onMouseEnter={() => { clearCloseTimer(); setNavOpen(item.href) }}
                onMouseLeave={() => scheduleClose(item.href)}
              >
                <button
                  className={['px-navlink', active ? 'px-navlink--active' : ''].join(' ')}
                  type="button"
                  onClick={() => {
                    setNavOpen(v => (v === item.href ? null : item.href))
                    setClubOpen(false)
                    setUserOpen(false)
                    clearCloseTimer()
                  }}
                  aria-expanded={open}
                >
                  {item.label}
                  <ChevronDown size={16} className={open ? 'px-rot' : ''} />
                </button>

                {open ? (
                  <div className="px-menu px-menu--nav" role="menu" onMouseEnter={clearCloseTimer} onMouseLeave={() => scheduleClose(item.href)}>
                    {item.children!.map(ch => (
                      <button
                        key={ch.href}
                        className="px-menuItem"
                        role="menuitem"
                        type="button"
                        onClick={() => {
                          setNavOpen(null)
                          clearCloseTimer()
                          router.push(ch.href)
                        }}
                      >
                        {ch.label}
                      </button>
                    ))}
                  </div>
                ) : null}
              </div>
            )
          })}
        </nav>

        {/* RIGHT */}
        <div className="px-right">
          <div className="px-icons px-desktopOnly">
            {cfg.right.search ? (
              <button className="px-icoBtn" type="button" aria-label="Buscar" onClick={() => router.push('/buscar')}>
                <Search size={18} />
              </button>
            ) : null}
            {cfg.right.notifications ? (
              <button className="px-icoBtn" type="button" aria-label="Notificaciones" onClick={() => router.push('/notificaciones')}>
                <Bell size={18} />
                {notifCount > 0 ? <span className="px-badge">{notifCount}</span> : null}
              </button>
            ) : null}
            {cfg.right.messages ? (
              <button className="px-icoBtn" type="button" aria-label="Mensajes" onClick={() => router.push('/mensajes')}>
                <Mail size={18} />
                {mailCount > 0 ? <span className="px-badge">{mailCount}</span> : null}
              </button>
            ) : null}
          </div>

          {cfg.right.login ? (
            <button className="px-loginBtn" type="button" onClick={onLogin}>
              Login
            </button>
          ) : null}

          {cfg.right.userMenu ? (
            <div className="px-dd">
              <button
                className="px-userBtn"
                type="button"
                onClick={() => {
                  setUserOpen(v => !v)
                  setClubOpen(false)
                  setNavOpen(null)
                  clearCloseTimer()
                }}
                aria-expanded={userOpen}
                aria-haspopup="menu"
              >
                <span className="px-avatar">
                  {user?.avatarUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={user.avatarUrl} alt="" />
                  ) : (
                    <span>{initials(user?.name ?? 'Usuario')}</span>
                  )}
                </span>

                <span className="px-userText">
                  <span className="px-userName">{shortName(user?.name ?? 'Usuario', 14)}</span>
                </span>

                <ChevronDown size={16} className={userOpen ? 'px-rot' : ''} />
              </button>

              {userOpen ? (
                <div className="px-menu" role="menu">
                  <button className="px-menuItem" role="menuitem" type="button" onClick={() => { setUserOpen(false); router.push('/perfil') }}>
                    <User size={16} />
                    Mi perfil
                  </button>

                  <button className="px-menuItem" role="menuitem" type="button" onClick={() => { setUserOpen(false); router.push('/actividad') }}>
                    <Activity size={16} />
                    Mi actividad
                  </button>

                  <button className="px-menuItem" role="menuitem" type="button" onClick={() => { setUserOpen(false); router.push('/ajustes') }}>
                    <Settings size={16} />
                    Preferencias
                  </button>

                  <div className="px-menuSep" />

                  <button className="px-menuItem px-menuItem--danger" role="menuitem" type="button" onClick={onLogout}>
                    <LogOut size={16} />
                    Cerrar sesión
                  </button>
                </div>
              ) : null}
            </div>
          ) : null}
        </div>
      </div>

      {/* Mobile drawer */}
      {mobileOpen ? (
        <div className="px-drawerBackdrop" role="presentation" onClick={() => setMobileOpen(false)}>
          <aside className="px-drawer" role="dialog" aria-modal="true" aria-label="Menú" onClick={e => e.stopPropagation()}>
            <div className="px-drawerTop">
              <div className="px-drawerTitle">Menú</div>
              <button className="px-drawerClose" type="button" aria-label="Cerrar" onClick={() => setMobileOpen(false)}>
                <X size={18} />
              </button>
            </div>

            <div className="px-drawerSection">
              <div className="px-drawerSectionTitle">Navegación</div>
              {mainNav.map(item => (
                <button
                  key={item.href}
                  className={['px-drawerItem', isActiveItem(item) ? 'px-drawerItem--active' : ''].join(' ')}
                  type="button"
                  onClick={() => router.push(item.href)}
                >
                  {item.label}
                  {item.dot ? <span className="px-dot" aria-hidden="true" /> : null}
                </button>
              ))}
            </div>

            <div className="px-drawerSection">
              <div className="px-drawerSectionTitle">Acciones</div>
              {cfg.right.notifications ? (
                <button className="px-drawerItem" type="button" onClick={() => router.push('/notificaciones')}>
                  <Bell size={16} /> Notificaciones {notifCount > 0 ? <span className="px-pill">{notifCount}</span> : null}
                </button>
              ) : null}
              {cfg.right.messages ? (
                <button className="px-drawerItem" type="button" onClick={() => router.push('/mensajes')}>
                  <Mail size={16} /> Mensajes {mailCount > 0 ? <span className="px-pill">{mailCount}</span> : null}
                </button>
              ) : null}
              {cfg.right.search ? (
                <button className="px-drawerItem" type="button" onClick={() => router.push('/buscar')}>
                  <Search size={16} /> Buscar
                </button>
              ) : null}
              {cfg.right.login ? (
                <button className="px-drawerItem" type="button" onClick={onLogin}>
                  Login
                </button>
              ) : null}
              {cfg.right.userMenu ? (
                <button className="px-drawerItem" type="button" onClick={onLogout}>
                  <LogOut size={16} /> Cerrar sesión
                </button>
              ) : null}
            </div>
          </aside>
        </div>
      ) : null}
    </header>
  )
}